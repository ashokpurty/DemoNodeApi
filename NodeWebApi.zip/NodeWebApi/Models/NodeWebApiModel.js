
var Employee = [];

Employee.push({employeeCode:'001', name:'ashok', age:'32', department:'Devloper', designation:'senior software engineer'});
module.exports = Employee;
