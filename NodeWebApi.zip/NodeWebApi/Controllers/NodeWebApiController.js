'use strict';

var employeeList = require('../Models/NodeWebApiModel');

exports.list_all_employee = function(req, res){
		res.json(employeeList);
};